#include <stdio.h>
#include <stdlib.h>
#include "functions.h"

/* needed header files .... */
/* declarations of functions import_JPEG_file and export_JPEG_file */

int main(int argc, char *argv[]){
  int m, n, c, iters;
  float kappa;
  image u, u_bar;
  unsigned char *image_chars;
  char *input_jpeg_filename;
  char *output_jpeg_filename;

  /* read from command line: kappa, iters, input_jpeg_filename, output_jpeg_filename */
  /* ... */

  kappa = 0.2;
  iters = 100;
  input_jpeg_filename = "mona_lisa_noisy.jpg";
  output_jpeg_filename = "mona_lisa_100_0_2.jpg";

  printf("import_JPEG_file\n");
  import_JPEG_file(input_jpeg_filename, &image_chars, &m, &n, &c);
  printf("m = %d, n = %d, num_comp = %d\n",m,n,c );
  printf("With %d iterations and kappa = %.2f\n",iters,kappa );
  printf("allocate_image: u and u_bar\n");
  allocate_image(&u, m, n);
  allocate_image(&u_bar, m, n);

  printf("convert_jpeg_to_image\n");
  convert_jpeg_to_image(image_chars, &u);
  printf("iso_diffusion_denoising\n");
  iso_diffusion_denoising(&u, &u_bar, kappa, iters);

  printf("convert_image_to_jpeg\n");
  convert_image_to_jpeg(&u_bar, image_chars);

  printf("export_JPEG_file\n");
  export_JPEG_file(output_jpeg_filename, image_chars, m, n, c, 75);

  printf("deallocate_image: u and u_bar\n");
  deallocate_image(&u);
  deallocate_image(&u_bar);

  return 0;
}
