
When you are in the serial/ or parallel/ directories you may
compile the programs by first typing "make clean" to make sure that you
are running the newest save of the program, the typing "make" in the terminal
to compile everything and make the outfile serial_main/parallel_main.

then for running the program u need:

Serial:
./serial_main kappa n_iter input-file output-file

Parallel:
mpirun -np number_processors ./parallel_main kappa n_iter input-file output-file
